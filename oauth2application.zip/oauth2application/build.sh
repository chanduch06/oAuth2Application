#!/bin/bash
pip install -r requirements.pip
python manage.py migrate                  # Apply database migrations
python manage.py collectstatic --noinput  # Collect static files

# Prepare log files and start outputting logs to stdout
#touch /oauth2application/logs/gunicorn.log
#touch /oauth2application/logs/access.log
#tail -n 0 -f /oauth2application/logs/*.log &

# Start Gunicorn processes
echo Starting django server.
#exec python manage.py runserver
echo "Done"
