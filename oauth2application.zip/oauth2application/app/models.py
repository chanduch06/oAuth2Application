from django.db import models
from django.contrib.auth.models import User


class Client(models.Model):
    name = models.CharField(max_length=50)
    client_id = models.CharField(max_length=50)
    client_secret = models.CharField(max_length=50)
    redirect_uris = models.URLField()
    authorization_type = models.CharField(max_length=50)

    def __str__(self):
        return self.name


class AuthToken(models.Model):
    client = models.ForeignKey('Client', related_name='authtoken')
    user = models.ForeignKey(User, related_name='authtoken')
    access_token = models.CharField(max_length=100)
    expiry = models.DateTimeField()
    refresh_token = models.CharField(max_length=100)
    scope = models.ManyToManyField('Scope', related_name='authtoken')

    def __str__(self):
        return self.access_token


class Scope(models.Model):
    name = models.CharField(max_length=50, unique=True)

    def __str__(self):
        return self.name


class Code(models.Model):
    authorization_code = models.CharField(max_length=50)
    scope = models.ManyToManyField('Scope', related_name='authorization_codes')
    client = models.ForeignKey(Client, related_name='authorization_codes')
    user = models.ForeignKey(User, related_name='authorization_codes')

    def __str__(self):
        return self.authorization_code
