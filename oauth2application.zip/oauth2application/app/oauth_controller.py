import string
import random
from app import models


class ClientDoesNotExist(Exception):
    pass


def create_hash(length):
    return ''.join(random.choice(string.ascii_lowercase + string.digits)
                   for _ in range(length))


def create_client(name, redirect_uri, authorization_type):
    client = models.Client.objects.create(
        name=name,
        client_id=create_hash(30),
        client_secret=create_hash(45),
        redirect_uris=redirect_uri,
        authorization_type=authorization_type
    )
    return client


def get_client(client_id):
    try:
        client = models.Client.objects.get(
            client_id=client_id)
    except models.Client.DoesNotExist:
        raise ClientDoesNotExist('Client Does Not Exist')
    return client
