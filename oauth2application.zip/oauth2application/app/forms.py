from django import forms


GRANT_CHOICES = (
    ('code', 'code'),
)


class RegisterAppForm(forms.Form):
    client_name = forms.CharField(label='Client name', max_length=100)
    client_id = forms.HiddenInput()
    client_secret = forms.HiddenInput()
    redirect_uri = forms.URLField(label='Redirect Uri')
    authorization_type = forms.ChoiceField(
        label='Authorization type', choices=GRANT_CHOICES)
