import json
from datetime import datetime, timedelta

from django.shortcuts import render
from django.contrib.auth import login
from django.contrib.auth import logout
from django.contrib.auth import authenticate
from django.contrib.auth.models import User
from django.db.utils import IntegrityError
from django.http import HttpResponse, HttpResponseBadRequest
from django.contrib.auth.decorators import login_required
# from django.views.decorators.csrf import csrf_protect
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponseRedirect

from app import forms
from app import models
from app import oauth_controller


EXPIRY_HOUR = 6


class UserAlreadyExist(Exception):
    pass


class CouldNotAuthenticate(Exception):
    pass


class UserNotActive(Exception):
    pass


class RedirectUriMismatch(Exception):
    pass


class AuthTokenNotFound(Exception):
    pass


def register(request):
    username = request.GET.get('username')
    password = request.GET.get('password')
    email = request.GET.get('email')
    try:
        user = User.objects.create(username=username, email=email)
        user.set_password(password)
        user.save()
    except IntegrityError:
        # raise UserAlreadyExist('User Already Exists')
        error_msg = json.dumps({'error': 'User Already Exists'})
        return HttpResponseBadRequest(error_msg)
    return HttpResponse('Successfully Registered')


def user_login(request):
    username = request.GET.get('username')
    password = request.GET.get('password')

    user = authenticate(username=username, password=password)
    if not user:
        raise CouldNotAuthenticate('Given Credentials are wrong')
    if not user.is_active:
        raise UserNotActive('User is not active')
    login(request, user)
    return HttpResponse('Successfully logged in')


@login_required
def user_logout(request):
    logout(request)
    return HttpResponse('Successfully logged out')


@login_required
def register_app(request):
    # if this is a POST request we need to process the form data
    if request.method == 'POST':
        form = forms.RegisterAppForm(request.POST)
        if form.is_valid():
            client_name = form.data.get('client_name')
            redirect_uri = form.data.get('redirect_uri')
            authorization_type = form.data.get('authorization_type')
            oauth_controller.create_client(
                client_name, redirect_uri, authorization_type)
            return HttpResponseRedirect('/app/thanks/')

    # if a GET (or any other method) we'll create a blank form
    else:
        form = forms.RegisterAppForm()

    return render(request, 'app/register_app.html/', {'form': form})


def say_thanks(request):
    return HttpResponse('Thank You')


@login_required
def verify_client(request):
    user = request.user
    client_id = request.GET.get('client_id')
    redirect_uri = request.GET.get('redirect_uri')
    scopes = request.GET.get('scopes')
    try:
        client = oauth_controller.get_client(client_id)
    except oauth_controller.ClientDoesNotExist:
        raise oauth_controller.ClientDoesNotExist('Client Not Found')
    if redirect_uri != client.redirect_uris:
        raise RedirectUriMismatch(
            'Please pass redirect_uri as defined while app registration')
    code = oauth_controller.create_hash(40)
    # Creating Code object for verification
    code_object = models.Code.objects.create(
        authorization_code=code, client=client, user=user)

    scopes = scopes.split(',')
    for scope in scopes:
        scope = models.Scope.objects.get_or_create(name=scope)[0]
        code_object.scope.add(scope)

    redirect_uri = '{}?code={}'.format(redirect_uri, code)
    return render(
        request,
        'app/ask_authorization.html/',
        {'client_name': client.name, 'redirect_uri': redirect_uri,
         'scopes': scopes})


@csrf_exempt
def get_access_token(request):
    code = request.POST.get('code')
    client_id = request.POST.get('client_id')
    client_secret = request.POST.get('client_secret')
    try:
        client = models.Client.objects.get(
            client_id=client_id, client_secret=client_secret)
    except models.Client.DoesNotExist:
        raise oauth_controller.ClientDoesNotExist('Client Not Found')
    try:
        code_object = models.Code.objects.get(
            authorization_code=code, client=client)
    except models.Code.DoesNotExist:
        raise CouldNotAuthenticate('Given Code is not valid')
    auth_token = models.AuthToken.objects.create(
        client=client, user=code_object.user,
        access_token=oauth_controller.create_hash(40),
        expiry=datetime.utcnow() + timedelta(hours=EXPIRY_HOUR),
        refresh_token=oauth_controller.create_hash(40)
    )
    for scope in code_object.scope.all():
        auth_token.scope.add(scope)

    access_token_data = {
        'access_token': auth_token.access_token,
        'refresh_token': auth_token.refresh_token,
        'expiry': auth_token.expiry
    }
    return HttpResponse(json.dumps(access_token_data, default=date_handler))


@csrf_exempt
def refresh_token(request):
    refresh_token = request.POST.get('refresh_token')
    access_token = request.POST.get('access_token')
    client_id = request.POST.get('client_id')
    client_secret = request.POST.get('client_secret')
    try:
        client = models.Client.objects.get(
            client_id=client_id, client_secret=client_secret)
    except models.Client.DoesNotExist:
        raise oauth_controller.ClientDoesNotExist('Client Not Found')
    try:
        auth_token = models.AuthToken.objects.get(
            client=client,
            access_token=access_token,
            refresh_token=refresh_token
        )
        new_access_token = oauth_controller.create_hash(40)
        new_expiry = datetime.utcnow() + timedelta(hours=EXPIRY_HOUR)
        auth_token.access_token = new_access_token
        auth_token.expiry = new_expiry
        auth_token.save()
    except models.AuthToken.DoesNotExist:
        raise AuthTokenNotFound('Given Access and Refresh token Not Found')

    data = {'access_token': new_access_token, 'expiry': new_expiry}
    return HttpResponse(json.dumps(data, default=date_handler))


def date_handler(obj):
    if hasattr(obj, 'isoformat'):
        return obj.isoformat()
    else:
        raise TypeError


def index(request):
    return render(request, 'app/index.html/')
