from django.contrib import admin
from app import models
# Register your models here.


@admin.register(models.Client)
class ClientAdmin(admin.ModelAdmin):
    list_display = ('name', 'client_id', 'client_secret', 'redirect_uris',
                    'authorization_type')


@admin.register(models.AuthToken)
class AuthTokenAdmin(admin.ModelAdmin):
    list_display = ('client', 'user', 'access_token', 'expiry',
                    'refresh_token',)


@admin.register(models.Code)
class CodeAdmin(admin.ModelAdmin):
    list_display = ('authorization_code', 'client', 'user')


@admin.register(models.Scope)
class ScopeAdmin(admin.ModelAdmin):
    list_display = ('name',)
