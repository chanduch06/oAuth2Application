from django.conf.urls import url
from app import views

urlpatterns = [
    url(r'^register/$', views.register),
    url(r'^login/$', views.user_login),
    url(r'^logout/$', views.user_logout),
    url(r'^application/$', views.register_app),
    url(r'^thanks/$', views.say_thanks),
    url(r'^authorize/$', views.verify_client),
    url(r'^oauthtoken/$', views.get_access_token),
    url(r'^refreshtoken/$', views.refresh_token),
    url(r'^index/$', views.index)
]
